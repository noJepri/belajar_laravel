luwih enak kentang
<?php /**PATH C:\Users\asus\uwu\resources\views/telo.blade.php ENDPATH**/ ?>